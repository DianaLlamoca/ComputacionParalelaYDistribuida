#Algoritmo Dijkstra-Scholten: Terminacion de procesos
class DijkstraScholten:
    def __init__(self, process_id, neighbors):
        self.process_id = process_id
        self.neighbors = neighbors
        self.parent = None
        self.children = set()
        self.active = True

    def send_message(self, recipient):
        recipient.receive_message(self, self.process_id)

    def receive_message(self, sender, sender_id):
        if self.parent is None:
            self.parent = sender
        self.children.add(sender_id)
        self.process_task()

    def process_task(self):
        #Se simula la tarea de procesamiento
        self.active = False
        self.check_termination()

    def check_termination(self):
        if not self.active and not self.children:
            if self.parent:
                self.parent.receive_termination(self.process_id)

    def receive_termination(self, child_id):
        self.children.remove(child_id)
        self.check_termination()


#Algoritmo de Ricart-Agrawala: Exclusion mutua
class RicartAgrawalaMutex:
    def __init__(self, node_id, num_nodes):
        self.node_id = node_id
        self.num_nodes = num_nodes
        self.clock = 0
        self.request_queue = []
        self.replies_received = 0

    def request_access(self):
        self.clock += 1
        self.request_queue.append((self.clock, self.node_id))
        for node in nodes:
            if node.node_id != self.node_id:
                node.receive_request(self.clock, self.node_id)

    def receive_request(self, timestamp, sender_id):
        self.clock = max(self.clock, timestamp) + 1
        self.request_queue.append((timestamp, sender_id))
        self.request_queue.sort()
        self.send_reply(sender_id)

    def send_reply(self, target_id):
        for node in nodes:
            if node.node_id == target_id:
                node.receive_reply(self.node_id)

    def receive_reply(self, sender_id):
        self.replies_received += 1
        if self.replies_received == self.num_nodes - 1:
            self.enter_critical_section()

    def enter_critical_section(self):
        print(f"Nodo {self.node_id} ingresando a la seccion critica")
        self.leave_critical_section()

    def leave_critical_section(self):
        self.replies_received = 0
        self.request_queue = [(t, n) for t, n in self.request_queue if n != self.node_id]
        for timestamp, node_id in self.request_queue:
            self.send_reply(node_id)
        print(f"Nodo {self.node_id} dejando la seccion critica")


#Algoritmo de sincronizacion de relojes: Algoritmo de Berkeley
class BerkeleyNode:
    def __init__(self, node_id, time):
        self.node_id = node_id
        self.time = time

    def adjust_time(self, offset):
        self.time += offset

class BerkeleyMaster:
    def __init__(self, nodes):
        self.nodes = nodes

    def synchronize_clocks(self):
        times = [node.time for node in self.nodes]
        average_time = sum(times) / len(times)
        for node in self.nodes:
            offset = average_time - node.time
            node.adjust_time(offset)
        return [(node.node_id, node.time) for node in self.nodes]

#Algoritmo Cheney para recoleccion de basura:
class CheneyCollector:
    def __init__(self, size):
        self.size = size
        self.from_space = [None] * size
        self.to_space = [None] * size
        self.free_ptr = 0

    def allocate(self, obj):
        if self.free_ptr >= self.size:
            self.collect()
        addr = self.free_ptr
        self.from_space[addr] = obj
        self.free_ptr += 1
        return addr

    def collect(self):
        self.to_space = [None] * self.size
        self.free_ptr = 0
        for obj in self.from_space:
            if obj is not None:
                self.copy(obj)
        self.from_space, self.to_space = self.to_space, self.from_space

    def copy(self, obj):
        addr = self.free_ptr
        self.to_space[addr] = obj
        self.free_ptr += 1
        return addr


#Clase Message
class Message:
    #Atributos para el remitente, contenido y marca de tiempo
    def __init__(self,sender,content,timestamp):
        self.sender=sender
        self.content=content
        self.timestamp=timestamp


#Clase Node
class Node:
    #Cada nodo debe tener un identificador, numero total de nodos y una referencia a la red
    def __init__(self,node_id,total_nodes,ref_red):
        self.node_id=node_id
        self.total_nodes=node_id
        self.ref_red=ref_red

    #Metodos:
    def enviar_mensajes(self,self.nodo,self.neighbors):
        for neighbor in neighbors:

    #Manejar solicitudes de exclusion usando Ricart-Agrawala y Dijkstra-Scholten
    def manejar_soli_exc_mut():
        #El algoritmo de Ricart-Agrawala se encuentra al inicio, por lo que se instancia un obtejo de dicha clase
        ricart_agrawala=RicartAgrawalaMutex(self.node_id,self.total_nodes) #SE especifica el ID del nodo y el numero de nodos

        #Se usa el algoritmo de DIjkstra-Scholten
        dijkstra_scholten=DijkstraScholten(self.node_id,self.total_nodes) #Se especifica el ID del nodo y sus vecinos


    def sincronizar_relojes(self,time):
        berkeley=BerkeleyNode(self.node_id,self.time) #SE especifica el Id del nodo y el tiempo


    def rec_bas_cheney(self,size):
        cheney=CheneyCollector(size)
