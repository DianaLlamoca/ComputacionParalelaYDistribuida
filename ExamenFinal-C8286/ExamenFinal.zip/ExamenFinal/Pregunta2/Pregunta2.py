#La primera tarea consiste en crear un algoritmo de Chandy-Lamport para tomar instantáneas:

from collections import defaultdict
#Algoritmo Chandy-Lamport
class Proceso():
    #Este proceso se encargará de iniciar la toma de instáneas:
    def __init__(self, id_proceso):
        self.id_proceso=id_proceso
        self.estado=None #Pues el proceso inicia la toma de instantáneas registrando su propio estado
        self.canal=defaultdict(list)
        self.proc_vec=[] #Acá se almacenará los procesos vecinos
        self.marcador_rec={} #Acá estarán los mensajes de marcador
        self.snapshot_local=None
        self.lock=threading.Lock() #Se crea un lock para asegurar que solo 1 proceso realice la toma de instantáneas 

    def colocar_vecinos(self,vecinos):
        self.vecinos=vecinos
        #Cada proceso debe recibir mensajes de marcador de los procesos (vecinos)
        for vec in vecinos:
            self.marcador_rec[vec.id_proceso]=False

    def iniciar_snapshot(self):
        with self.lock:
            self.snapshot_local=self.estado
            print(f"El proceso {self.id_proceso} toma su snapshot local {self.local_snapshot}")
            self.env_marc_msg()
   
   #El método se encargará de enviar mensajes de marcador a todos sus vecinos
    def env_marc_msg(self):
        #El proceso envía mensajes de marcador a sus vecinos correspondientes
        for vec in self.vecinos:
            self.env_msg(vec,"marcador")

    #Se implementa el método que se encargará de enviar el mensaje
    def env_msg(self,vecino,msg_tipo,cont=None):
        msg=(msg_tipo,self.id_proceso,cont)
        #Cada vecino recivirà el mensaje
        vecino.rec_msg(msg)

    #Se crea el método de recibir mensaje
    def rec_msg(self,msg):
        msg_tipo,id_envia,cont=msg
        with self.lock:
            if msg_tipo=="marcador":
                if not self.marcador_rec[id_envia]:
                    self.marcador_rec[id_envia]=True
                    #En caso no haya snapshot local, el proceso debe realizarlo
                    if self.snapshot_local is None:
                        self.snapshot_local=self.estado
                        print(f"El proceso {self.id_proceso} toma su snapshot local {self.snapshot_local}")
                        #SE llama al metodo para enviar el marcador de mensaje
                        self.env_marc_msg()
                    #EN caso lo haya, registra el estado del canal
                    else:
                        self.canal[id_envia].append(cont)
                else:
                    self.canal[id_envia].append(cont)
            else:
                if self.snapshot_local is not None:
                    self.canal[id_envia].append(cont)
                else:
                    self.proc_msg(msg)

    #Se realiza una simulacion de un procesamiento de un mensaje
    def proc_msg(self,msg):
        print(f"Proceso {self.id_proceso} recibe el mensaje desde el proceso {msg[1]}: {msg[2]}")

    def actualizar_estado(self,nuevo_estado):
        self.estado=nuevo_estado


#ALgoritmo de Raymond
class Raymond:
    def __init__(self,id_nodo,nodo_padre=None):
        self.id_nodo=id_nodo
        self.nodo_padre=nodo_padre
        self.pos_token=(nodo_padre is None)
        self.cola_solicitud=[] #Pues cada nodo enviara una solicitud a su padre para acceder al recurso

    def acceso_solicitud(self):
        if self.pos_token:
            self.ing_sec_crit() #Si pose el token, recien puede entrar a la seccion critica
        else:
            self.cola_solicitud.append(self.id_nodo) #De lo contrario, tendria que esperar, ya que la solicitud se encontrara en la cola
            self.env_sol_padre() #Y se envia la solicitud al padre

    def env_sol_padre(self):
        if self.nodo_padre:
            self.padre.rec_sol(self)

    def rec_sol(self,solicitante):
        if not self.pos_token:
            self.cola_solicitud.append(solicitante.id_nodo)
            self.env_sol_padre()
        elif solicitante.id_nodo==self.id_nodo:
            self.ing_sec_crit()
        else:
            self.enviar_token(solicitante)

    def enviar_token(self,solicitante):
        self.pos_token=False
        solicitante.rec_token(self)

    def rec_token(self,envia):
        self.pos_token=True
        if self.cola_solicitud and self.cola_solicitud[0]==self.id_nodo:
            self.ing_sec_crit()
        else:
            self.env_tok_sig()
    
    def env_tok_sig():
        id_nodo_sig=self.cola_solicitud.pop(0)
        nodo_sig=[nodo for nodo in nodos if nodo.id_nodo==id_nodo_sig[0]]

    def ing_sec_crit(self):
        print(f"NOdo {self.id_nodo} ingresando a la seccion critica")
        self.sal_seccion_crit()

    def sal_seccion_crit(self):
        print(f"NOdo {self.id_nodo} dejando la seccion critica")
        if self.cola_solicitud:
            self.env_tok_sig()


#Relojes vectoriales
class RelojVectorial:
    def __init__(self, num_nodos, node_id):
        self.reloj = [0] * num_nodos
        self.nodo_id = nodo_id

    def tick(self):
        self.reloj[self.nodo_id] += 1

    def send_event(self):
        self.tick()
        return self.reloj[:]

    def receive_event(self, vector_recibido):
        for i in range(len(self.reloj)):
            self.reloj[i] = max(self.reloj[i], vector_recibido[i])
        self.reloj[self.nodo_id] += 1


#Recolector de basura generacional:
class GenerationalCollector:
    def __init__(self, tamaño):
        self.tamaño = tamaño
        self.gen_joven = [None] * tamaño
        self.gen_vie = [None] * tamaño
        self.young_ptr = 0
        self.old_ptr = 0

    def allocate(self, obj, old=False):
        if old:
            if self.old_ptr >= self.tamaño:
                self.collect_old()
            addr = self.old_ptr
            self.gen_vie[addr] = obj
            self.old_ptr += 1
        else:
            if self.young_ptr >= self.tamaño:
                self.collect_young()
            addr = self.young_ptr
            self.gen_joven[addr] = obj
            self.young_ptr += 1
        return addr

    def collect_young(self):
        self.gen_vie = self.gen_vie + [obj for obj in self.gen_joven if obj is not None]
        self.gen_joven = [None] * self.tamaño
        self.young_ptr = 0

    def collect_old(self):
        self.gen_vie = [obj for obj in self.gen_vie if obj is not None]
        self.gen_vie = len(self.gen_vie)
        self.gen_vie += [None] * (self.tamaño - self.old_ptr)




